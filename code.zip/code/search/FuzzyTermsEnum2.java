/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search;

import java.io.IOException;
import java.util.function.Supplier;
import org.apache.lucene.index.BaseTermsEnum;
import org.apache.lucene.index.ImpactsEnum;
import org.apache.lucene.index.PostingsEnum;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermState;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.util.Attribute;
import org.apache.lucene.util.AttributeImpl;
import org.apache.lucene.util.AttributeReflector;
import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.BytesRefBuilder;
import org.apache.lucene.util.IOBooleanSupplier;
import org.apache.lucene.util.UnicodeUtil;
import org.apache.lucene.util.automaton.CompiledAutomaton;

/**
 * Subclass of TermsEnum for enumerating all terms that are similar to the specified filter term.
 *
 * <p>Term enumerations are always ordered by {@link BytesRef#compareTo}. Each term in the
 * enumeration is greater than all that precede it.
 */
public final class FuzzyTermsEnum2 extends BaseTermsEnum {

  // NOTE: we can't subclass FilteredTermsEnum here because we need to sometimes change actualEnum:
  private TermsEnum actualEnum;

  private final AttributeSource atts;

  // We use this to communicate the score (boost) of the current matched term we are on back to
  // MultiTermQuery.TopTermsBlendedFreqScoringRewrite that is collecting the best (default 50)
  // matched terms:
  private final BoostAttribute boostAtt;

  // MultiTermQuery.TopTermsBlendedFreqScoringRewrite tells us the worst boost still in its queue
  // using this att,
  // which we use to know when we can reduce the automaton from ed=2 to ed=1, or ed=0 if only single
  // top term is collected:
  

  private final CompiledAutomaton automata;
  private final Terms terms;
  private final int termLength;
  private final Term term;

  

  // Maximum number of edits we will accept.  This is either 2 or 1 (or, degenerately, 0) passed by
  // the user originally,
  // but as we collect terms, we can lower this (e.g. from 2 to 1) if we detect that the term queue
  // is full, and all
  // collected terms are ed=1:

  /**
   * Constructor for enumeration of all terms from specified <code>reader</code> which share a
   * prefix of length <code>prefixLength</code> with <code>term</code> and which have at most {@code
   * maxEdits} edits.
   *
   * <p>After calling the constructor the enumeration is already pointing to the first valid term if
   * such a term exists.
   *
   * @param terms Delivers terms.
   * @param term Pattern term.
   * @param maxEdits Maximum edit distance.
   * @param prefixLength the length of the required common prefix
   * @param transpositions whether transpositions should count as a single edit
   * @throws IOException if there is a low-level IO error
   */
  public FuzzyTermsEnum2(
      Terms terms, Term term)
      throws IOException {
    this(
        terms,
        new AttributeSource(),
        term,
        () -> new FuzzyAutomatonBuilder2(term));
  }

  /**
   * Constructor for enumeration of all terms from specified <code>reader</code> which share a
   * prefix of length <code>prefixLength</code> with <code>term</code> and which have at most {@code
   * maxEdits} edits.
   *
   * <p>After calling the constructor the enumeration is already pointing to the first valid term if
   * such a term exists.
   *
   * @param terms Delivers terms.
   * @param atts An AttributeSource used to share automata between segments
   * @param term Pattern term.
   * @param maxEdits Maximum edit distance.
   * @param prefixLength the length of the required common prefix
   * @param transpositions whether transpositions should count as a single edit
   * @throws IOException if there is a low-level IO error
   */
  FuzzyTermsEnum2(
      Terms terms,
      AttributeSource atts,
      Term term)
      throws IOException {
    this(
        terms,
        atts,
        term,
        () -> new FuzzyAutomatonBuilder2(term));
  }

  public FuzzyTermsEnum2(
      Terms terms,
      AttributeSource atts,
      Term term,
      Supplier<FuzzyAutomatonBuilder2> automatonBuilder)
      throws IOException {

    this.terms = terms;
    this.atts = atts;
    this.term = term;

    //System.out.println("this.term:"+this.term);
    
    this.boostAtt = atts.addAttribute(BoostAttribute.class);

    atts.addAttributeImpl(new AutomatonAttributeImpl());
    AutomatonAttribute aa = atts.addAttribute(AutomatonAttribute.class);
    aa.init(automatonBuilder);

    this.automata = aa.getAutomata();
    this.termLength = aa.getTermLength();
   //System.out.println("termLength"+termLength);

    
    bottomChanged(null);
  }

  /**
   * Sets the maximum non-competitive boost, which may allow switching to a lower max-edit automaton
   * at run time
   */
  

  /** Gets the boost of the current term */
  public float getBoost() {
    return boostAtt.getBoost();
  }

  /** return an automata-based enum for matching up to editDistance from lastTerm, if possible */
  public TermsEnum getAutomatonEnum(BytesRef lastTerm) throws IOException {
    final CompiledAutomaton compiled = automata;
    BytesRef initialSeekTerm;
    if (lastTerm == null) {
      // This is the first enum we are pulling:
      initialSeekTerm = null;
    } else {
      // We are pulling this enum (e.g., ed=1) after iterating for a while already (e.g., ed=2):
      initialSeekTerm = compiled.floor(lastTerm, new BytesRefBuilder());
    }
    return terms.intersect(compiled, initialSeekTerm);
  }

  /**
   * fired when the max non-competitive boost has changed. this is the hook to swap in a smarter
   * actualEnum.
   */
  public void bottomChanged(BytesRef lastTerm) throws IOException {
    

    // true if the last term encountered is lexicographically equal or after the bottom term in the
    // PQ
    
    // as long as the max non-competitive boost is >= the max boost
    // for some edit distance, keep dropping the max edit distance.
          

    if (lastTerm == null) {
      // This is a very powerful optimization: the maximum edit distance has changed.  This happens
      // because we collect only the top scoring
      // N (= 50, by default) terms, and if e.g. maxEdits=2, and the queue is now full of matching
      // terms, and we notice that the worst entry
      // in that queue is ed=1, then we can switch the automata here to ed=1 which is a big speedup.
      actualEnum = getAutomatonEnum(lastTerm);
    }
  }
public static float calculateLengthRatio(String str1, String str2) {
        // Focus on the substring after '#' if it exists, otherwise use the whole string
        String processedStr1 = str1.contains("#") ? str1.substring(str1.indexOf("#") + 1) : str1;
        String processedStr2 = str2.contains("#") ? str2.substring(str2.indexOf("#") + 1) : str2;

        // Calculate the length of each string based on the number of "//" and adding 2
        int length1 = processedStr1.split("//").length + 1;
        int length2 = processedStr2.split("//").length + 1;

        // Return the ratio of the lengths
        return (float) length1 / length2;
    }
public static float calculateLengthRatio2(String str1, String str2) {
        // Focus on the substring after '#' if it exists, otherwise use the whole string
        String processedStr1 = str1.contains("#") ? str1.substring(str1.indexOf("#") + 1) : str1;
        //String processedStr2 = str2.contains("#") ? str2.substring(str2.indexOf("#") + 1) : str2;

        // Calculate the length of each string based on the number of "//" and adding 2
        int length1 = processedStr1.split("//").length + 1;
        //int length2 = processedStr2.split("//").length + 1;

        // Return the ratio of the lengths
        return (float) length1;
// length2;
    }

  @Override
  public BytesRef next() throws IOException {


    BytesRef term;

    term = actualEnum.next();
    if (term == null) {
      // end
      return null;
    }

    

    // we know the outer DFA always matches.
    // now compute exact edit distance
   

    
      final int codePointCount = UnicodeUtil.codePointCount(term);
      int minTermLength = Math.min(codePointCount, termLength);

      float similarity = calculateLengthRatio2(this.term.text(),term.utf8ToString());
//System.out.println("similarity:" + similarity);

      boostAtt.setBoost(similarity);
    

    
    return term;
  }

  /** returns true if term is within k edits of the query term */
  public boolean matches(BytesRef termIn) {
 return automata.runAutomaton.run(termIn.bytes, termIn.offset, termIn.length);
  }

  // proxy all other enum calls to the actual enum
  @Override
  public int docFreq() throws IOException {
    return actualEnum.docFreq();
  }

  @Override
  public long totalTermFreq() throws IOException {
    return actualEnum.totalTermFreq();
  }

  @Override
  public PostingsEnum postings(PostingsEnum reuse, int flags) throws IOException {
    return actualEnum.postings(reuse, flags);
  }

  @Override
  public ImpactsEnum impacts(int flags) throws IOException {
    return actualEnum.impacts(flags);
  }

  @Override
  public void seekExact(BytesRef term, TermState state) throws IOException {
    actualEnum.seekExact(term, state);
  }

  @Override
  public TermState termState() throws IOException {
    return actualEnum.termState();
  }

  @Override
  public long ord() throws IOException {
    return actualEnum.ord();
  }

  @Override
  public AttributeSource attributes() {
    return atts;
  }

  @Override
  public boolean seekExact(BytesRef text) throws IOException {
    return actualEnum.seekExact(text);
  }

  @Override
  public IOBooleanSupplier prepareSeekExact(BytesRef text) throws IOException {
    return actualEnum.prepareSeekExact(text);
  }

  @Override
  public SeekStatus seekCeil(BytesRef text) throws IOException {
    return actualEnum.seekCeil(text);
  }

  @Override
  public void seekExact(long ord) throws IOException {
    actualEnum.seekExact(ord);
  }

  @Override
  public BytesRef term() throws IOException {
    return actualEnum.term();
  }

  /**
   * Thrown to indicate that there was an issue creating a fuzzy query for a given term. Typically
   * occurs with terms longer than 220 UTF-8 characters, but also possible with shorter terms
   * consisting of UTF-32 code points.
   */
  public static class FuzzyTermsException2 extends RuntimeException {
    FuzzyTermsException2(String term, Throwable cause) {
      super("Term too complex: " + term, cause);
    }
  }

  /**
   * Used for sharing automata between segments
   *
   * <p>Levenshtein automata are large and expensive to build; we don't want to build them directly
   * on the query because this can blow up caches that use queries as keys; we also don't want to
   * rebuild them for every segment. This attribute allows the FuzzyTermsEnum2 to build the automata
   * once for its first segment and then share them for subsequent segment calls.
   */
  private interface AutomatonAttribute extends Attribute {
    CompiledAutomaton getAutomata();

    int getTermLength();

    void init(Supplier<FuzzyAutomatonBuilder2> builder);
  }

  private static class AutomatonAttributeImpl extends AttributeImpl implements AutomatonAttribute {

    private CompiledAutomaton automata;
    private int termLength;

    @Override
    public CompiledAutomaton getAutomata() {
      return automata;
    }

    @Override
    public int getTermLength() {
      return termLength;
    }

    @Override
    public void init(Supplier<FuzzyAutomatonBuilder2> supplier) {
      //System.out.println("debug1:");


      if (automata != null) {
        return;
      }
//System.out.println("debug2:");

      FuzzyAutomatonBuilder2 builder = supplier.get();
      this.termLength = builder.getTermLength();
      this.automata = builder.buildMaxEditAutomaton();
    }

    @Override
    public void clear() {
      this.automata = null;
    }

    @Override
    public void reflectWith(AttributeReflector reflector) {
      throw new UnsupportedOperationException();
    }

    @Override
    public void copyTo(AttributeImpl target) {
      throw new UnsupportedOperationException();
    }
  }
}
