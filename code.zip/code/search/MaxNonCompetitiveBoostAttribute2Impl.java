/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search;

import org.apache.lucene.util.AttributeImpl;
import org.apache.lucene.util.AttributeReflector;
import org.apache.lucene.util.BytesRef;

/**
 * Implementation class for {@link MaxNonCompetitiveBoostAttribute}.
 *
 * @lucene.internal
 */
public final class MaxNonCompetitiveBoostAttribute2Impl extends AttributeImpl
    implements MaxNonCompetitiveBoostAttribute2 {
  private float maxNonCompetitiveBoost = Float.NEGATIVE_INFINITY;
  private BytesRef[] competitiveTerms = null;

  @Override
  public void setMaxNonCompetitiveBoost(final float maxNonCompetitiveBoost) {
    this.maxNonCompetitiveBoost = maxNonCompetitiveBoost;
  }

  @Override
  public float getMaxNonCompetitiveBoost() {
    return maxNonCompetitiveBoost;
  }

  @Override
  public void setCompetitiveTerms(final BytesRef[] competitiveTerms) {
    this.competitiveTerms = competitiveTerms;
  }

  @Override
  public BytesRef[] getCompetitiveTerms() {
    return competitiveTerms;
  }

  @Override
  public void clear() {
    maxNonCompetitiveBoost = Float.NEGATIVE_INFINITY;
    competitiveTerms = null;
  }

  @Override
  public void copyTo(AttributeImpl target) {
    final MaxNonCompetitiveBoostAttribute2Impl t = (MaxNonCompetitiveBoostAttribute2Impl) target;
    t.setMaxNonCompetitiveBoost(maxNonCompetitiveBoost);
    t.setCompetitiveTerms(competitiveTerms);
  }

  @Override
  public void reflectWith(AttributeReflector reflector) {
    reflector.reflect(
        MaxNonCompetitiveBoostAttribute2.class, "maxNonCompetitiveBoost", maxNonCompetitiveBoost);
    reflector.reflect(MaxNonCompetitiveBoostAttribute2.class, "competitiveTerms", competitiveTerms);
  }
}
