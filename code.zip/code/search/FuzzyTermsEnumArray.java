/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search;

import org.apache.lucene.index.TermsEnumArray;
import java.io.IOException;
import java.util.function.Supplier;
import org.apache.lucene.index.BaseTermsEnum;
import org.apache.lucene.index.ImpactsEnum;
import org.apache.lucene.index.PostingsEnum;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermState;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.util.Attribute;
import org.apache.lucene.util.AttributeImpl;
import org.apache.lucene.util.AttributeReflector;
import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.BytesRefBuilder;
import org.apache.lucene.util.IOBooleanSupplier;
import org.apache.lucene.util.UnicodeUtil;
import org.apache.lucene.util.automaton.CompiledAutomaton;
import org.apache.lucene.index.TermsEnum.SeekStatus;

/**
 * Subclass of TermsEnum for enumerating all terms that are similar to the specified filter term.
 *
 * <p>Term enumerations are always ordered by {@link BytesRef#compareTo}. Each term in the
 * enumeration is greater than all that precede it.
 */
public final class FuzzyTermsEnumArray extends TermsEnumArray<FuzzyTermsEnum2> {

  // NOTE: we can't subclass FilteredTermsEnum here because we need to sometimes change actualEnum:
 


  // We use this to communicate the score (boost) of the current matched term we are on back to
  // MultiTermQuery.TopTermsBlendedFreqScoringRewrite that is collecting the best (default 50)
  // matched terms:

  // MultiTermQuery.TopTermsBlendedFreqScoringRewrite tells us the worst boost still in its queue
  // using this att,
  // which we use to know when we can reduce the automaton from ed=2 to ed=1, or ed=0 if only single
  // top term is collected:
  

  
  

  // Maximum number of edits we will accept.  This is either 2 or 1 (or, degenerately, 0) passed by
  // the user originally,
  // but as we collect terms, we can lower this (e.g. from 2 to 1) if we detect that the term queue
  // is full, and all
  // collected terms are ed=1:

  /**
   * Constructor for enumeration of all terms from specified <code>reader</code> which share a
   * prefix of length <code>prefixLength</code> with <code>term</code> and which have at most {@code
   * maxEdits} edits.
   *
   * <p>After calling the constructor the enumeration is already pointing to the first valid term if
   * such a term exists.
   *
   * @param terms Delivers terms.
   * @param term Pattern term.
   * @param maxEdits Maximum edit distance.
   * @param prefixLength the length of the required common prefix
   * @param transpositions whether transpositions should count as a single edit
   * @throws IOException if there is a low-level IO error
   */
  public FuzzyTermsEnumArray(Terms[] termss, Term[] terms) throws IOException {
    // Call the other constructor first
    this(termss, createAttributeSources(terms.length), terms, createSuppliers(terms));
}

// Method to initialize AttributeSource array
private static AttributeSource[] createAttributeSources(int length) {
    AttributeSource[] attributeSources = new AttributeSource[length];
    for (int i = 0; i < length; i++) {
        attributeSources[i] = new AttributeSource();
    }
    return attributeSources;
}

// Method to initialize Supplier array
private static Supplier<FuzzyAutomatonBuilder2>[] createSuppliers(Term[] terms) {
    @SuppressWarnings("unchecked") // To suppress warnings for generic array creation
    Supplier<FuzzyAutomatonBuilder2>[] suppliers = new Supplier[terms.length];
    for (int i = 0; i < terms.length; i++) {
        final Term term = terms[i];
//System.out.println("terms[i]:"+terms[i]);

        suppliers[i] = () -> new FuzzyAutomatonBuilder2(term);
    }
    return suppliers;
}


  /**
   * Constructor for enumeration of all terms from specified <code>reader</code> which share a
   * prefix of length <code>prefixLength</code> with <code>term</code> and which have at most {@code
   * maxEdits} edits.
   *
   * <p>After calling the constructor the enumeration is already pointing to the first valid term if
   * such a term exists.
   *
   * @param terms Delivers terms.
   * @param atts An AttributeSource used to share automata between segments
   * @param term Pattern term.
   * @param maxEdits Maximum edit distance.
   * @param prefixLength the length of the required common prefix
   * @param transpositions whether transpositions should count as a single edit
   * @throws IOException if there is a low-level IO error
   */
  FuzzyTermsEnumArray(
      Terms[] termss,
      AttributeSource[] attss,
      Term[] terms)
      throws IOException {
 
    this(
        termss,
        attss,
        terms,
        createSuppliers(terms));
  }

  private FuzzyTermsEnumArray(
      Terms[] termss,
      AttributeSource[] attss,
      Term[] terms,
      Supplier<FuzzyAutomatonBuilder2>[] automatonBuilders)
      throws IOException {
      termsEnumArray=new FuzzyTermsEnum2[terms.length];
for (int i=0;i<terms.length;i++){
System.out.println("FuzzyTermsEnumArrayterms[i]:"+terms[i]);

termsEnumArray[i]=new FuzzyTermsEnum2(termss[i],attss[i],terms[i],automatonBuilders[i]);
}
     }

  /**
   * Sets the maximum non-competitive boost, which may allow switching to a lower max-edit automaton
   * at run time
   */
  

  /** Gets the boost of the current term */
  public float getBoost() {
    
    return termsEnumArray[0].getBoost();
 }
// public float[] getBoosts() {
//     float[] boosts = new float[termsEnumArray.length];
//     for (int i = 0; i < termsEnumArray.length; i++) {
//         boosts[i] = termsEnumArray[i].getBoost();  // Assuming getBoost() is available in each BaseTermsEnum
//     }
//     return boosts;
// }

  /** return an automata-based enum for matching up to editDistance from lastTerm, if possible */
  private TermsEnum[] getAutomatonEnums(BytesRef[] lastTerms) throws IOException {
    TermsEnum[]result=new TermsEnum[lastTerms.length];
    for(int i=0;i<lastTerms.length;i++){
    result[i]=termsEnumArray[i].getAutomatonEnum(lastTerms[i]);
}
return result;
  }

  /**
   * fired when the max non-competitive boost has changed. this is the hook to swap in a smarter
   * actualEnum.
   */
  private void bottomChangeds(BytesRef[] lastTerms) throws IOException {
    for(int i=0;i<termsEnumArray.length;i++){
    termsEnumArray[i].bottomChanged(lastTerms[i]);
}

    // true if the last term encountered is lexicographically equal or after the bottom term in the
    // PQ
    
    // as long as the max non-competitive boost is >= the max boost
    // for some edit distance, keep dropping the max edit distance.
          

      }
@Override
public BytesRef[] next() throws IOException {
    BytesRef[] result = new BytesRef[termsEnumArray.length];
    String[] suffixes = new String[termsEnumArray.length];
    BytesRef[] currentTerms = new BytesRef[termsEnumArray.length];

    while (true) {
        // Get the current terms and suffixes
        String minSuffix = null;
        String maxSuffix = null;

        for (int i = 0; i < termsEnumArray.length; i++) {
            if (currentTerms[i] == null) {
                currentTerms[i] = termsEnumArray[i].next(); // Advance if term is not loaded
                if (currentTerms[i] == null) {
                    return null; // If any TermsEnum is exhausted, terminate
                }
            }

            String termString = currentTerms[i].utf8ToString();
System.out.println("FuzzyTermsEnumArraytermString:"+termString);

            int separatorIndex = termString.indexOf('#');
            if (separatorIndex != -1) {
                suffixes[i] = termString.substring(separatorIndex + 1); // Extract suffix
                if (minSuffix == null || suffixes[i].compareTo(minSuffix) < 0) {
                    minSuffix = suffixes[i];
                }
                if (maxSuffix == null || suffixes[i].compareTo(maxSuffix) > 0) {
                    maxSuffix = suffixes[i];
                }
            }
        }

        // If all suffixes are the same, return the current terms and move forward
        if (minSuffix.equals(maxSuffix)) {
            for (int i = 0; i < termsEnumArray.length; i++) {
                result[i] = currentTerms[i];
 // Store the aligned terms
                currentTerms[i]=null;
            }

            //super.next(); // Call the parent class's next() method before returning
            return result;
        }

        // Advance TermsEnum instances with suffixes smaller than maxSuffix
        for (int i = 0; i < termsEnumArray.length; i++) {
            if (!suffixes[i].equals(maxSuffix)) {
                currentTerms[i] = termsEnumArray[i].next(); // Advance to the next term
                if (currentTerms[i] == null) {
                    return null; // If any TermsEnum is exhausted, terminate
                }
            }
        }
    }
}
        /** returns true if term is within k edits of the query term */
  private boolean matches(BytesRef[] termsIn) {
    boolean result = true;
    for (int i = 0; i < termsIn.length; i++) {
        result=termsEnumArray[i].matches(termsIn[i]);
        if(result==false){return result;}
    }
    return result;
}

// private boolean[] matches(BytesRef[] termsIn) {
//     boolean[] results = new boolean[termsIn.length];
//     for (int i = 0; i < termsIn.length; i++) {
//         results[i] =termsEnumArray[i].matches(termsIn[i]);
//     }
//     return results;
// }


  // proxy all other enum calls to the actual enum
  
  
  
  
  
 
  
  /**
   * Thrown to indicate that there was an issue creating a fuzzy query for a given term. Typically
   * occurs with terms longer than 220 UTF-8 characters, but also possible with shorter terms
   * consisting of UTF-32 code points.
   */
  
  /**
   * Used for sharing automata between segments
   *
   * <p>Levenshtein automata are large and expensive to build; we don't want to build them directly
   * on the query because this can blow up caches that use queries as keys; we also don't want to
   * rebuild them for every segment. This attribute allows the FuzzyTermsEnumArray to build the automata
   * once for its first segment and then share them for subsequent segment calls.
   */

}
