/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search;
import org.apache.lucene.search.PhraseQuery2;
import java.util.List;
import java.util.ArrayList;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.apache.lucene.index.IndexReaderContext;
import org.apache.lucene.index.LeafReaderContext;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermState;
import org.apache.lucene.index.TermStates;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.util.ArrayUtil;
import org.apache.lucene.util.IOSupplier;
import org.apache.lucene.util.InPlaceMergeSorter;

/**
 * A {@link Query} that blends index statistics across multiple terms. This is particularly useful
 * when several terms should produce identical scores, regardless of their index statistics.
 *
 * <p>For instance imagine that you are resolving synonyms at search time, all terms should produce
 * identical scores instead of the default behavior, which tends to give higher scores to rare
 * terms.
 *
 * <p>An other useful use-case is cross-field search: imagine that you would like to search for
 * {@code john} on two fields: {@code first_name} and {@code last_name}. You might not want to give
 * a higher weight to matches on the field where {@code john} is rarer, in which case {@link
 * BlendedPhraseQuery} would help as well.
 *
 * @lucene.experimental
 */
public final class BlendedPhraseQuery extends Query {

  /** A Builder for {@link BlendedPhraseQuery}. */
  public static class Builder {

    private int numPhrases = 0;
    private Term[][] termss = new Term[0][];

    private float[] boosts = new float[0];

    private TermStates[][] contextss = new TermStates[0][];
    private int[][] positionss=new int[0][];
    private RewriteMethod rewriteMethod = DISJUNCTION_MAX_REWRITE;

    /** Sole constructor. */
    public Builder() {}

    /**
     * Set the {@link RewriteMethod}. Default is to use {@link
     * BlendedPhraseQuery#DISJUNCTION_MAX_REWRITE}.
     *
     * @see RewriteMethod
     */
    public Builder setRewriteMethod(RewriteMethod rewiteMethod) {
      this.rewriteMethod = rewiteMethod;
      return this;
    }

    /**
     * Add a new {@link Term} to this builder, with a default boost of {@code 1}.
     *
     * @see #add(Term, float)
     */
    public Builder add(Term[] terms,int[] positions) {
      return add(terms, 1f,positions);
    }

    /**
     * Add a {@link Term} with the provided boost. The higher the boost, the more this term will
     * contribute to the overall score of the {@link BlendedPhraseQuery}.
     */
    public Builder add(Term[] terms, float boost,int[]positions) {
      return add(terms, boost, null,positions);
    }

    /**
     * Expert: Add a {@link Term} with the provided boost and context. This method is useful if you
     * already have a {@link TermStates} object constructed for the given term.
     */
    public Builder add(Term[] terms, float boost, TermStates[] contexts,int positions[]) {
      if (numPhrases >= IndexSearcher.getMaxClauseCount()) {
        throw new IndexSearcher.TooManyClauses();
      }
      termss = ArrayUtil.grow(termss, numPhrases + 1);
      boosts = ArrayUtil.grow(boosts, numPhrases + 1);
      contextss = ArrayUtil.grow(contextss, numPhrases + 1);
      positionss = ArrayUtil.grow(positionss, numPhrases + 1);

      termss[numPhrases] = terms;
      boosts[numPhrases] = boost;
      contextss[numPhrases] = contexts;
      positionss[numPhrases]=positions;
      numPhrases += 1;
      return this;
    }

    /** Build the {@link BlendedPhraseQuery}. */
    public BlendedPhraseQuery build() {
      return new BlendedPhraseQuery(
          ArrayUtil.copyOfSubArray(termss, 0, numPhrases),
          ArrayUtil.copyOfSubArray(boosts, 0, numPhrases),
          ArrayUtil.copyOfSubArray(contextss, 0, numPhrases),
ArrayUtil.copyOfSubArray(positionss, 0, numPhrases),

          rewriteMethod);
    }
  }

  /**
   * A {@link RewriteMethod} defines how queries for individual terms should be merged.
   *
   * @lucene.experimental
   * @see BlendedPhraseQuery#BOOLEAN_REWRITE
   * @see BlendedPhraseQuery.DisjunctionMaxRewrite
   */
  public abstract static class RewriteMethod {

    /** Sole constructor */
    protected RewriteMethod() {}

    /** Merge the provided sub queries into a single {@link Query} object. */
    public abstract Query rewrite(Query[] subQueries);
  }

  /**
   * A {@link RewriteMethod} that adds all sub queries to a {@link BooleanQuery}. This {@link
   * RewriteMethod} is useful when matching on several fields is considered better than having a
   * good match on a single field.
   */
  public static final RewriteMethod BOOLEAN_REWRITE =
      new RewriteMethod() {
        @Override
        public Query rewrite(Query[] subQueries) {
          BooleanQuery.Builder merged = new BooleanQuery.Builder();
          for (Query query : subQueries) {
            merged.add(query, Occur.SHOULD);
          }
          return merged.build();
        }
      };

  /**
   * A {@link RewriteMethod} that creates a {@link DisjunctionMaxQuery} out of the sub queries. This
   * {@link RewriteMethod} is useful when having a good match on a single field is considered better
   * than having average matches on several fields.
   */
  public static class DisjunctionMaxRewrite extends RewriteMethod {

    private final float tieBreakerMultiplier;

    /**
     * This {@link RewriteMethod} will create {@link DisjunctionMaxQuery} instances that have the
     * provided tie breaker.
     *
     * @see DisjunctionMaxQuery
     */
    public DisjunctionMaxRewrite(float tieBreakerMultiplier) {
      this.tieBreakerMultiplier = tieBreakerMultiplier;
    }

    @Override
    public Query rewrite(Query[] subQueries) {
      return new DisjunctionMaxQuery(Arrays.asList(subQueries), tieBreakerMultiplier);
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == null || getClass() != obj.getClass()) {
        return false;
      }
      DisjunctionMaxRewrite that = (DisjunctionMaxRewrite) obj;
      return tieBreakerMultiplier == that.tieBreakerMultiplier;
    }

    @Override
    public int hashCode() {
      return 31 * getClass().hashCode() + Float.floatToIntBits(tieBreakerMultiplier);
    }
  }

  /** {@link DisjunctionMaxRewrite} instance with a tie-breaker of {@code 0.01}. */
  public static final RewriteMethod DISJUNCTION_MAX_REWRITE = new DisjunctionMaxRewrite(0.01f);

  private final Term[][] termss;
  private final float[] boosts;
  private final TermStates[][] contextss;
  private final int[][] positionss;
  private final RewriteMethod rewriteMethod;

  private BlendedPhraseQuery(
      Term[][] termss, float[] boosts, TermStates[][] contextss, int[][] positionss,RewriteMethod rewriteMethod) {
    assert termss.length == boosts.length;
    assert termss.length == contextss.length;
    this.termss = termss;
    this.boosts = boosts;
    this.contextss = contextss;
    this.positionss=positionss;
    this.rewriteMethod = rewriteMethod;

    // we sort terms so that equals/hashcode does not rely on the order
    new InPlaceMergeSorter() {

      @Override
      protected void swap(int i, int j) {
        Term[] tmpTerms = termss[i];
        termss[i] = termss[j];
        termss[j] = tmpTerms;

        TermStates[] tmpContexts = contextss[i];
        contextss[i] = contextss[j];
        contextss[j] = tmpContexts;

        float tmpBoost = boosts[i];
        boosts[i] = boosts[j];
        boosts[j] = tmpBoost;
        int[] tmppositions =positionss[i];
        positionss[i] =positionss[j];
        positionss[j] = tmppositions;

      }

      @Override
      protected int compare(int i, int j) {
    // Assuming termss[i] and termss[j] are arrays or lists of comparable elements
    int length = Math.min(termss[i].length, termss[j].length);

    for (int k = 0; k < length; k++) {
        int cmp1 = termss[i][k].compareTo(termss[j][k]);
        int cmp2= Integer.compare(positionss[i][k], positionss[j][k]);
        if (cmp1 != 0) {
            return cmp1;  // Return the first non-zero comparison result
        }
        if(cmp2!=0){
            return cmp2;
}
    }

    // If all elements are equal, compare by length
    return Integer.compare(termss[i].length, termss[j].length);
}

    }.sort(0, termss.length);
  }

  @Override
  public boolean equals(Object other) {
    return sameClassAs(other) && equalsTo(getClass().cast(other));
  }

  private boolean equalsTo(BlendedPhraseQuery other) {
    return Arrays.equals(termss, other.termss)
        && Arrays.equals(contextss, other.contextss)
        && Arrays.equals(boosts, other.boosts)
        && Arrays.equals(positionss, other.positionss)

        && rewriteMethod.equals(other.rewriteMethod);
  }

  @Override
  public int hashCode() {
    int h = classHash();
    h = 31 * h + Arrays.hashCode(termss);
    h = 31 * h + Arrays.hashCode(contextss);
    h = 31 * h + Arrays.hashCode(boosts);
    h = 31 * h + rewriteMethod.hashCode();
    return h;
  }

  @Override
  public String toString(String field) {
    StringBuilder builder = new StringBuilder("Blended(");
    for (int i = 0; i < termss.length; ++i) {
      if (i != 0) {
        builder.append(" ");
      }
      Query phraseQuery = new PhraseQuery2(0,termss[i],PhraseQuery2.incrementalPositions(termss[i].length),contextss[i]);

      if (boosts[i] != 1f) {
        phraseQuery = new BoostQuery(phraseQuery, boosts[i]);
      }
      builder.append(phraseQuery.toString(field));
    }
    builder.append(")");
    return builder.toString();
  }
  public static BooleanQuery buildBooleanQuery(Term[] terms, int[] positions) {
        BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
        
        List<Term> currentGroup = new ArrayList<>();
        int lastPosition = positions[0];
        
        for (int i = 0; i < terms.length; i++) {
            if (positions[i] != lastPosition) {
                addTermorPhraseQuery(booleanQuery, currentGroup);
                currentGroup.clear();
            }
            currentGroup.add(terms[i]);
            lastPosition = positions[i];
        }
        
        addTermorPhraseQuery(booleanQuery, currentGroup);
        
        return booleanQuery.build();
    }
    
    private static void addTermorPhraseQuery(BooleanQuery.Builder booleanQuery, List<Term> group) {
        if (group.isEmpty()) return;
        
        if (group.size() == 1) {
            booleanQuery.add(new TermQuery(group.get(0)), BooleanClause.Occur.MUST);
        } else {
            PhraseQuery.Builder phraseQuery = new PhraseQuery.Builder();
            String field = group.get(0).field();
            
            for (int i = 0; i < group.size(); i++) {
                if (!group.get(i).field().equals(field)) {
                    throw new IllegalArgumentException("All terms in a phrase query must have the same field");
                }
                phraseQuery.add(group.get(i), i);
            }
            booleanQuery.add(phraseQuery.build(), BooleanClause.Occur.MUST);
        }
    }

  @Override
  public final Query rewrite(IndexSearcher indexSearcher) throws IOException {
    final TermStates[][] contextss = ArrayUtil.copyArray(this.contextss);
    /* 
    for (int i = 0; i < contextss.length; ++i) {
      if (contextss[i] == null
          || contexts[i].wasBuiltFor(indexSearcher.getTopReaderContext()) == false) {
        contexts[i] = TermStates.build(indexSearcher, terms[i], true);
      }
    }
    */
    // Compute aggregated doc freq and total term freq
    // df will be the max of all doc freqs
    // ttf will be the sum of all total term freqs
    int df = 0;
    long ttf = 0;
    for (TermStates[] ctxs : contextss) {
      int df2=Integer.MAX_VALUE;
      long ttf2=Long.MAX_VALUE;
      for(TermStates ctx:ctxs){
        df2=Math.min(df2,ctx.docFreq());
        ttf2=Math.min(ttf2,ctx.totalTermFreq());

      }
      df = Math.max(df, df2);
      ttf += ttf2;
    }

    for (int i = 0; i < contextss.length; ++i) {
      for (int j = 0; j < contextss[i].length; ++j) {
        contextss[i][j] = adjustFrequencies(indexSearcher.getTopReaderContext(), contextss[i][j], df, ttf);

      }

      //contexts[i] = adjustFrequencies(indexSearcher.getTopReaderContext(), contexts[i], df, ttf);
    }

    Query[] phraseQueries = new Query[termss.length];
    for (int i = 0; i < termss.length; ++i) {
      //phraseQueries[i] = new PhraseQuery2(0,termss[i],PhraseQuery2.incrementalPositions(termss[i].length),contextss[i]);
      phraseQueries[i] =buildBooleanQuery(termss[i],positionss[i]);
      if (boosts[i] != 1f) {
        phraseQueries[i] = new BoostQuery(phraseQueries[i], boosts[i]);
      }
    }
    return rewriteMethod.rewrite(phraseQueries);
  }

  @Override
  public void visit(QueryVisitor visitor) {
    System.out.println("bzd");
    // Term[] termsToVisit =
    //     Arrays.stream(terms).filter(t -> visitor.acceptField(t.field())).toArray(Term[]::new);
    // if (termsToVisit.length > 0) {
    //   QueryVisitor v = visitor.getSubVisitor(Occur.SHOULD, this);
    //   v.consumeTerms(this, termsToVisit);
    // }
  }

  private static TermStates adjustFrequencies(
      IndexReaderContext readerContext, TermStates ctx, int artificialDf, long artificialTtf)
      throws IOException {
    List<LeafReaderContext> leaves = readerContext.leaves();
    TermStates newCtx = new TermStates(readerContext);
    for (int i = 0; i < leaves.size(); ++i) {
      IOSupplier<TermState> supplier = ctx.get(leaves.get(i));
      if (supplier == null) {
        continue;
      }
      TermState termState = supplier.get();
      if (termState == null) {
        continue;
      }
      newCtx.register(termState, i);
    }
    newCtx.accumulateStatistics(artificialDf, artificialTtf);
    return newCtx;
  }
}
