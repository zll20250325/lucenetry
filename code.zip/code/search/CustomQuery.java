/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search;

import org.apache.lucene.index.Term;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.automaton.Automaton;
import org.apache.lucene.util.automaton.Operations;
/**
 * A Query that matches documents containing terms with a specified prefix. A CustomQuery is built
 * by QueryParser for input like <code>app*</code>.
 *
 * <p>This query uses the {@link MultiTermQuery#CONSTANT_SCORE_BLENDED_REWRITE} rewrite method.
 */
public class CustomQuery extends AutomatonQuery {

  /** Constructs a query for terms starting with <code>prefix</code>. */
public static RewriteMethod defaultRewriteMethod(int maxExpansions) {
    return new MultiTermQuery.TopTermsBlendedFreqScoringRewrite(maxExpansions);
  }
  public CustomQuery(Term term) {
    this(term, defaultRewriteMethod(50));
  }

  /**
   * Constructs a query for terms starting with <code>prefix</code> using a defined RewriteMethod
   */
  public CustomQuery(Term term, RewriteMethod rewriteMethod) {
    super(term, toAutomaton(term.bytes()), true, rewriteMethod);
  }

  /** Build an automaton accepting all terms with the specified prefix. */
 public static Automaton toAutomaton(BytesRef term) {
    System.out.println("term.utf8ToString():" + term.utf8ToString());

    String termStr = term.utf8ToString();
    int hashIndex = termStr.indexOf("#");

    // Split the term into prefix and wildcard parts
    String prefixStr = (hashIndex != -1) ? termStr.substring(0, hashIndex) : "";
    String wildcardStr = (hashIndex != -1) ? termStr.substring(hashIndex + 1) : termStr;

    // Process the wildcard part (split by "//")
    String[] parts2 = wildcardStr.split("//");
System.out.println("parts2.length:" + parts2.length);
System.out.println("parts2:" + parts2[0]);
StringBuilder wildcardBuilder = new StringBuilder("*");

for (int i = 0; i < parts2.length; i++) {
    if (i == parts2.length - 1) {
        // For the last element, append the entire part with lbcsg*rbcsg/* to the prefix except the last character
        wildcardBuilder.append(parts2[i], 0, parts2[i].length() - 1)
                       .append("lbcsg*rbcsg/*");  // append the last character
    } else {
        wildcardBuilder.append(parts2[i]).append("lbcsg*rbcsg/*/");
    }
}


String wildcard = wildcardBuilder.toString();
    //String wildcard = "*" + String.join("/*/", parts2) + "*";
    Term wildcard2 = new Term("doesntmatter", wildcard);
    System.out.println("wildcard2:" + wildcard2);

    // Create the automaton
    Automaton wildcardAutomaton = WildcardQuery.toAutomaton(wildcard2, 10000);
    
    if (!prefixStr.isEmpty()) {
        // If there's a prefix, concatenate it with the wildcard automaton
        BytesRef prefix = new BytesRef(prefixStr);
        return Operations.determinize(
            Operations.concatenate(
                PrefixQuery.toAutomaton(prefix),
                wildcardAutomaton
            ), 10000);
    } else {
        // If there's no prefix, just return the wildcard automaton
System.out.println("wildcard:" + wildcard);

        return wildcardAutomaton;
    }
}

  /** Returns the prefix of this query. */
  public Term getPrefix() {
    return term;
  }

  /** Prints a user-readable version of this query. */
  @Override
  public String toString(String field) {
    StringBuilder buffer = new StringBuilder();
    if (!getField().equals(field)) {
      buffer.append(getField());
      buffer.append(':');
    }
    buffer.append(term.text());
    buffer.append('*');
    return buffer.toString();
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + term.hashCode();
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (!super.equals(obj)) {
      return false;
    }
    // super.equals() ensures we are the same class
    CustomQuery other = (CustomQuery) obj;
    if (!term.equals(other.term)) {
      return false;
    }
    return true;
  }
private boolean matches(BytesRef termIn) {
    return compiled.runAutomaton.run(termIn.bytes, termIn.offset, termIn.length);
  }
public static void main(String[] args) {
        // Create a term with a prefix, for example "app"
        Term term = new Term("field", "xiang#");
        
        // Create an instance of CustomQuery using the term
        CustomQuery query = new CustomQuery(term);

        // Test the match method with a BytesRef
        BytesRef testTerm = new BytesRef("xiang#pao//jun//jun//jun/");
        boolean isMatch = query.matches(testTerm);
        
        // Output the result
        System.out.println("Match found: " + isMatch);
    }

}
