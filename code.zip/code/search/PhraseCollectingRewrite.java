/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search;

//import org.apache.lucene.util.PhraseAttribute;
import java.io.IOException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexReaderContext;
import org.apache.lucene.index.LeafReaderContext;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermStates;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.index.TermsEnumArray;


abstract class PhraseCollectingRewrite<B> extends MultiPhraseQuery2.RewriteMethod {

  /** Return a suitable builder for the top-level Query for holding all expanded terms. */
  protected abstract B getTopLevelBuilder() throws IOException;

  /** Finalize the creation of the query from the builder. */
  protected abstract Query build(B builder);

  /** Add a MultiTermQuery term to the top-level query builder. */
  protected final void addClause(B topLevel, Term[] terms, int[] docCounts, float boost,int[] positions)
      throws IOException {
    addClause(topLevel, terms, docCounts, boost, null,positions);
  }

  protected abstract void addClause(
      B topLevel, Term[] terms, int[] docCounts, float boost, TermStates[] statess,int[] positions) throws IOException;

  final void collectPhrases(IndexReader reader, MultiPhraseQuery2 query, PhraseCollector collector)
      throws IOException {
    IndexReaderContext topReaderContext = reader.getContext();
    for (LeafReaderContext context : topReaderContext.leaves()) {
      final Terms terms = context.reader().terms(query.field);
      if (terms == null) {
        // field does not exist
        continue;
      }

      final TermsEnumArray termsEnumArray = getTermsEnumArray(query, terms, collector.attributes);
      //final int[] positions=getPositions(query);
      assert termsEnumArray != null;
      boolean tmp=true;
      for(int i=0;i<termsEnumArray.termsEnumArray.length;i++){
      if (termsEnumArray.termsEnumArray[0] == TermsEnum.EMPTY){tmp=false;
break;}
}

      if (!tmp) continue;

      collector.setReaderContext(topReaderContext, context);
      collector.setNextEnumArray(termsEnumArray);
      BytesRef[] bytess;
      while ((bytess = termsEnumArray.next()) != null) {
        if (!collector.collect(bytess))
          return; // interrupt whole term collection, so also don't iterate other subReaders
      }
    }
  }

  abstract static class PhraseCollector {

    protected LeafReaderContext readerContext;
    protected IndexReaderContext topReaderContext;

    public void setReaderContext(
        IndexReaderContext topReaderContext, LeafReaderContext readerContext) {
      this.readerContext = readerContext;
      this.topReaderContext = topReaderContext;
    }

    /** attributes used for communication with the enum */
    public final AttributeSource attributes = new AttributeSource();
    
    //private final PhraseAttribute phraseAtt =
              //attributes.addAttribute(PhraseAttribute.class);
 
    /** return false to stop collecting */
    public abstract boolean collect(BytesRef[] bytes) throws IOException;
    //public abstract boolean collect() throws IOException;


    /** the next segment's {@link TermsEnum} that is used to collect terms */
    public abstract void setNextEnumArray(TermsEnumArray termsEnumArray) throws IOException;
  }
}
