/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search;

import org.apache.lucene.util.BytesRefArray2;
import org.apache.lucene.index.TermsEnumArray;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermState;
import org.apache.lucene.index.TermStates;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.util.ArrayUtil;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.BytesRefBuilder;

/**
 * Base rewrite method for collecting only the top terms via a priority queue.
 *
 * @lucene.internal Only public to be accessible by spans package.
 */
public abstract class TopPhrasesRewrite<B> extends PhraseCollectingRewrite<B> {

  private final int size;

  /**
   * Create a TopTermsBooleanQueryRewrite for at most <code>size</code> terms.
   *
   * <p>NOTE: if {@link IndexSearcher#getMaxClauseCount} is smaller than <code>size</code>, then it
   * will be used instead.
   */
  public TopPhrasesRewrite(int size) {
    this.size = size;
  }

  /** return the maximum priority queue size */
  public int getSize() {
    return size;
  }

  /**
   * return the maximum size of the priority queue (for boolean rewrites this is
   * BooleanQuery#getMaxClauseCount).
   */
  protected abstract int getMaxSize();

  @Override
  public final Query rewrite(IndexSearcher indexSearcher, final MultiPhraseQuery2 query)
      throws IOException {
    final int maxSize = Math.min(size, getMaxSize());
    final PriorityQueue<ScorePhrase> spQueue = new PriorityQueue<>();
    collectPhrases(
        indexSearcher.getIndexReader(),
        query,
        new PhraseCollector() {
          private final MaxNonCompetitiveBoostAttribute2 maxBoostAtt =
              attributes.addAttribute(MaxNonCompetitiveBoostAttribute2.class);

          private final Map<BytesRefArray2, ScorePhrase> visitedPhrases = new HashMap<>();

          private TermsEnumArray termsEnumArray;
          private BoostAttribute boostAtt;
          private ScorePhrase sp;

          @Override
          public void setNextEnumArray(TermsEnumArray termsEnumArray) {
            this.termsEnumArray = termsEnumArray;

            assert compareToLastPhrase(null);

            // lazy init the initial ScoreTerm because comparator is not known on ctor:
            if (sp == null) {
TermStates[]tmp5=new TermStates[termsEnumArray.termsEnumArray.length];
for(int i=0;i<termsEnumArray.termsEnumArray.length;i++){

tmp5[i]=new TermStates(topReaderContext);
}
sp = new ScorePhrase(tmp5);
}
            boostAtt = termsEnumArray.attributes().addAttribute(BoostAttribute.class);
          }

          // for assert:
          private BytesRefBuilder[] lastPhrase;

          // private boolean compareToLastTerm(BytesRef t) {
          //   if (lastTerm == null && t != null) {
          //     lastTerm = new BytesRefBuilder();
          //     lastTerm.append(t);
          //   } else if (t == null) {
          //     lastTerm = null;
          //   } else {
          //     assert lastTerm.get().compareTo(t) < 0 : "lastTerm=" + lastTerm + " t=" + t;
          //     lastTerm.copyBytes(t);
          //   }
          //   return true;
          // }
          
          private boolean compareToLastPhrase(BytesRef[] p) {
            if (lastPhrase == null && p != null) {
                lastPhrase = new BytesRefBuilder[p.length];
                for (int i = 0; i < p.length; i++) {
                    lastPhrase[i] = new BytesRefBuilder();
                    lastPhrase[i].append(p[i]);
                }
            } else if (p == null) {
                lastPhrase = null;
            } else {
                for (int i = 0; i < p.length; i++) {
                    assert lastPhrase[i].get().compareTo(p[i]) < 0 : "lastPhrase=" + lastPhrase[i] + " p=" + p[i];
                    lastPhrase[i].copyBytes(p[i]);
                }
            }
            return true;
        }
        
          @Override
          public boolean collect(BytesRef[] bytess) throws IOException {
            final float boost = boostAtt.getBoost();
            //BytesRef[]bytess=phraseAtt.getPhrase();
            // make sure within a single seg we always collect
            // terms in order
            assert compareToLastPhrase(bytess);

            // System.out.println("TTR.collect term=" + bytes.utf8ToString() + " boost=" + boost + "
            // ord=" + readerContext.ord);
            // ignore uncompetitive hits
            if (spQueue.size() == maxSize) {
              final ScorePhrase p = spQueue.peek();
              if (boost < p.boost) return true;
              if( (boost == p.boost) && new BytesRefArray2(bytess).compareTo(p.bytess) > 0) return true;
            }
            ScorePhrase p = visitedPhrases.get(new BytesRefArray2(bytess));
            final TermState[] states = termsEnumArray.termStates();
            assert states != null;
            if (p != null) {
              // if the term is already in the PQ, only update docFreq of term in PQ
              assert p.boost == boost : "boost should be equal in all segment TermsEnums";
for(int i=0;i<p.termStates.length;i++)
{
              p.termStates[i].register(
                  states[i], readerContext.ord, termsEnumArray.termsEnumArray[i].docFreq(), termsEnumArray.termsEnumArray[i].totalTermFreq());}
            } else {
              // add new entry in PQ, we must clone the term, else it may get overwritten!
for(int i=0;i<bytess.length;i++){
              sp.bytess[i].copyBytes(bytess[i]);
}
              sp.boost = boost;
BytesRef[]tmp=new BytesRef[sp.bytess.length];

for(int i=0;i<sp.bytess.length;i++){
    tmp[i]=sp.bytess[i].get();
}
              visitedPhrases.put(new BytesRefArray2(tmp), sp);
              assert sp.termStates[0].docFreq() == 0;

for(int i=0;i<sp.bytess.length;i++)

{
              sp.termStates[i].register(
                  states[i], readerContext.ord, termsEnumArray.termsEnumArray[i].docFreq(), termsEnumArray.termsEnumArray[i].totalTermFreq());}
              spQueue.offer(sp);
              // possibly drop entries from queue
              if (spQueue.size() > maxSize) {
                sp = spQueue.poll();
                BytesRef[]tmp2=new BytesRef[sp.bytess.length];

for(int i=0;i<sp.bytess.length;i++){
    tmp2[i]=sp.bytess[i].get();
}

visitedPhrases.remove(tmp2);
for(int i=0;i<sp.termStates.length;i++){
                sp.termStates[i].clear(); // reset the termstate!
}
              } else {
TermStates[]tmp6=new TermStates[termsEnumArray.termsEnumArray.length];
for(int i=0;i<termsEnumArray.termsEnumArray.length;i++){

tmp6[i]=new TermStates(topReaderContext);
}

                sp = new ScorePhrase(tmp6);
              }
              assert spQueue.size() <= maxSize : "the PQ size must be limited to maxSize";
              // set maxBoostAtt with values to help FuzzyTermsEnum to optimize
              if (spQueue.size() == maxSize) {
                p = spQueue.peek();
                maxBoostAtt.setMaxNonCompetitiveBoost(p.boost);
                BytesRef[]tmp3=new BytesRef[p.bytess.length];
                for(int i=0;i<p.bytess.length;i++){
               tmp3[i]=p.bytess[i].get();
}
              maxBoostAtt.setCompetitiveTerms(tmp3);
              }
            }

            return true;
          }
        });

    final B b = getTopLevelBuilder();
    final ScorePhrase[] scorePhrases = spQueue.toArray(new ScorePhrase[spQueue.size()]);
    ArrayUtil.timSort(scorePhrases, (sp1, sp2) -> sp1.compareTo(sp2));

    for (final ScorePhrase sp : scorePhrases) {
      //final Term term = new Term(query.field, st.bytes.toBytesRef());
final Term[] terms = new Term[sp.bytess.length];
for (int i=0;i<sp.bytess.length;i++){
      terms[i]=new Term(query.field,sp.bytess[i].toBytesRef());
}

      // We allow negative term scores (fuzzy query does this, for example) while collecting the
      // terms,
      // but truncate such boosts to 0.0f when building the query:
      int[] tmp4=new int[sp.termStates.length];
      //int[] positions=new int[sp.bytess.length];

  for(int i=0;i<sp.termStates.length;i++){
    tmp4[i]=sp.termStates[i].docFreq();
}
      addClause(b, terms, tmp4, Math.max(0.0f, sp.boost), sp.termStates,query.getPositions()); // add to query
    }
    return build(b);
  }

  @Override
  public int hashCode() {
    return 31 * size;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    final TopPhrasesRewrite<?> other = (TopPhrasesRewrite<?>) obj;
    if (size != other.size) return false;
    return true;
  }

  static final class ScorePhrase implements Comparable<ScorePhrase> {
    public BytesRefBuilder[] bytess;
    public float boost;
    public final TermStates[] termStates;

    public ScorePhrase(TermStates[] termStates) {
        this.termStates = termStates;
        // Initialize the bytess array with the same length as the termStates array
        this.bytess = new BytesRefBuilder[termStates.length];
        for (int i = 0; i < termStates.length; i++) {
            this.bytess[i] = new BytesRefBuilder(); // Initialize each BytesRefBuilder
        }
    }

    // @Override
    // public int compareTo(ScorePhrase other) {
    //   if (this.boost == other.boost) return other.bytess[0].get().compareTo(this.bytess[0].get());
    //   else return Float.compare(this.boost, other.boost);
    // }
    @Override
public int compareTo(ScorePhrase other) {
    if (this.boost == other.boost) {
        int minLength = Math.min(this.bytess.length, other.bytess.length);
        
        // Compare each element until a difference is found
        for (int i = 0; i < minLength; i++) {
            int result = this.bytess[i].get().compareTo(other.bytess[i].get());
            if (result != 0) {
                return result;
            }
        }
        
        // If all compared elements are equal, compare based on the lengths of the arrays
        return Integer.compare(this.bytess.length, other.bytess.length);
    } else {
        return Float.compare(this.boost, other.boost);
    }
}
  }
}
