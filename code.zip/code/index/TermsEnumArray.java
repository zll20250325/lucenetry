package org.apache.lucene.index;

import java.io.IOException;
import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.IOBooleanSupplier;
import org.apache.lucene.index.TermsEnum.SeekStatus;

public class TermsEnumArray<T extends TermsEnum> {

  public T[] termsEnumArray;

  private AttributeSource atts = null;

public AttributeSource attributes() {
    if (atts == null) {
      atts = new AttributeSource();
    }
    return atts;
  }


  public BytesRef[] next() throws IOException {
    BytesRef[] result = new BytesRef[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      result[i] = termsEnumArray[i].next();
    }
    return result;
  }
/*
  public TermsEnumArray(T[] termsEnumArray) {
    this.termsEnumArray = termsEnumArray;
  }
*/
  public AttributeSource[] attributess() {
    AttributeSource[] result = new AttributeSource[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      result[i] = termsEnumArray[i].attributes();
    }
    return result;
  }

  public boolean seekExact(BytesRef[] texts) throws IOException {
    boolean found = true;
    for (int i = 0; i < termsEnumArray.length; i++) {
      if (!termsEnumArray[i].seekExact(texts[i])) {
        found = false;
      }
    }
    return found;
  }

  public IOBooleanSupplier[] prepareSeekExact(BytesRef[] texts) throws IOException {
    IOBooleanSupplier[] suppliers = new IOBooleanSupplier[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      suppliers[i] = termsEnumArray[i].prepareSeekExact(texts[i]); // assuming one IOBooleanSupplier per TermsEnum
    }
    return suppliers;
  }

  public SeekStatus[] seekCeil(BytesRef[] texts) throws IOException {
    SeekStatus[] statuses = new SeekStatus[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      statuses[i] = termsEnumArray[i].seekCeil(texts[i]); // assuming one SeekStatus per TermsEnum
    }
    return statuses;
  }

  public void seekExact(long[] ords) throws IOException {
    for (int i = 0; i < termsEnumArray.length; i++) {
      termsEnumArray[i].seekExact(ords[i]);
    }
  }

  public void seekExact(BytesRef[] terms, TermState[] states) throws IOException {
    for (int i = 0; i < termsEnumArray.length; i++) {
      termsEnumArray[i].seekExact(terms[i], states[i]);
    }
  }

  public BytesRef[] terms() throws IOException {
    BytesRef[] terms = new BytesRef[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      terms[i] = termsEnumArray[i].term(); // assuming one term per TermsEnum
    }
    return terms;
  }

  public long[] ords() throws IOException {
    long[] ords = new long[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      ords[i] = termsEnumArray[i].ord(); // assuming one ord per TermsEnum
    }
    return ords;
  }

  public int[] docFreqs() throws IOException {
    int[] docFreqs = new int[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      docFreqs[i] = termsEnumArray[i].docFreq(); // assuming one docFreq per TermsEnum
    }
    return docFreqs;
  }

  public long[] totalTermFreqs() throws IOException {
    long[] totalTermFreqs = new long[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      totalTermFreqs[i] = termsEnumArray[i].totalTermFreq(); // assuming one totalTermFreq per TermsEnum
    }
    return totalTermFreqs;
  }

  public PostingsEnum[] postingss(PostingsEnum[] reuses) throws IOException {
    PostingsEnum[] postings = new PostingsEnum[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      postings[i] = termsEnumArray[i].postings(reuses[i]); // assuming one PostingsEnum per TermsEnum
    }
    return postings;
  }

  public PostingsEnum[] postingss(PostingsEnum[] reuses, int[] flags) throws IOException {
    PostingsEnum[] postings = new PostingsEnum[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      postings[i] = termsEnumArray[i].postings(reuses[i], flags[i]); // assuming one PostingsEnum per TermsEnum
    }
    return postings;
  }

  public ImpactsEnum[] impactss(int[] flags) throws IOException {
    ImpactsEnum[] impacts = new ImpactsEnum[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      impacts[i] = termsEnumArray[i].impacts(flags[i]); // assuming one ImpactsEnum per TermsEnum
    }
    return impacts;
  }

  public TermState[] termStates() throws IOException {
    TermState[] termStates = new TermState[termsEnumArray.length];
    for (int i = 0; i < termsEnumArray.length; i++) {
      termStates[i] = termsEnumArray[i].termState(); // assuming one TermState per TermsEnum
    }
    return termStates;
  }
}
