package org.apache.lucene.analysis;

import java.io.IOException;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.TokenStream;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;
import java.io.Reader;
import java.io.StringReader;
import java.util.Stack;
import java.util.ArrayList;

public class XmlPathAnalyzer extends Analyzer {

    @Override
    protected TokenStreamComponents createComponents(String fieldName) {
        Tokenizer tokenizer = new XmlPathTokenizer();
        return new TokenStreamComponents(tokenizer);
    }

    private static class XmlPathTokenizer extends Tokenizer {
        private final CharTermAttribute charTermAttr = addAttribute(CharTermAttribute.class);
        private final OffsetAttribute offsetAttribute0 = addAttribute(OffsetAttribute.class);
        private final PositionIncrementAttribute posincreatt = addAttribute(PositionIncrementAttribute.class);

        private String[] tokens = null;
        private ArrayList<Integer> startOffsets = new ArrayList<>();
        private ArrayList<Integer> endOffsets = new ArrayList<>();
        private ArrayList<Integer> posincrs = new ArrayList<>();
        private int tokenIndex = 0;

        @Override
        public boolean incrementToken() throws IOException {
            if (tokens == null) {
                tokens = parseAndTokenize();
            }
//System.out.println("tokens.length"+tokens.length);
try{
            if (tokenIndex < tokens.length) {
                clearAttributes();
                offsetAttribute0.setOffset(startOffsets.get(tokenIndex), endOffsets.get(tokenIndex));
                charTermAttr.append(tokens[tokenIndex]);
                posincreatt.setPositionIncrement(posincrs.get(tokenIndex));
                tokenIndex++;
                return true;
            }}
catch (IndexOutOfBoundsException e) {System.out.println("IndexOutOfBoundsException");
tokens = null;
            startOffsets = new ArrayList<>();
            endOffsets = new ArrayList<>();
            posincrs = new ArrayList<>();
            tokenIndex = 0;
            return false;
}

            tokens = null;
            startOffsets = new ArrayList<>();
            endOffsets = new ArrayList<>();
            posincrs = new ArrayList<>();
            tokenIndex = 0;
            return false;
        }

        private String wrapXml(Reader inputReader) throws IOException {
            StringBuilder sb = new StringBuilder();
            int character;
            while ((character = inputReader.read()) != -1) {
                sb.append((char) character);
            }
            return "<root>" + sb.toString() + "</root>";
        }

        private String[] parseAndTokenize() {
            StringBuilder allTokens = new StringBuilder();
            try {
                SAXParserFactory factory = SAXParserFactory.newInstance();
                factory.setFeature("http://apache.org/xml/features/nonvalidating/load-dtd-grammar", false);
                factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
                SAXParser parser = factory.newSAXParser();

                StandardAnalyzer standardAnalyzer = new StandardAnalyzer();
                String wrappedXml = wrapXml(input);

                Reader wrappedReader = new StringReader(wrappedXml);
                try {
                    parser.parse(new InputSource(wrappedReader), new DefaultHandler() {
                        private final Stack<String> pathStack = new Stack<>();
                        private int lastEndOffset = 0;
                        private int tmpOffset = 0;

                        @Override
                        public void startElement(String uri, String localName, String qName, Attributes attributes) {
                            pathStack.push(qName);
                        }

                        @Override
                        public void endElement(String uri, String localName, String qName) {
                            pathStack.pop();
                        }

                        @Override
                        public void characters(char[] ch, int start, int length) {
                            String text = new String(ch, start, length).trim();
String currentPath = "/" + String.join("//", pathStack) + "/";
if (!currentPath.equals("/root/")){
allTokens.append(currentPath.substring(6)).append(" ");
        int startOffset0 = lastEndOffset;
        int endOffset0 = lastEndOffset;
        startOffsets.add(startOffset0);
        endOffsets.add(endOffset0);
        int posincr1 = 1;
        posincrs.add(posincr1);
}
                            if (!text.isEmpty()) {
                                

                                try {
                                    TokenStream tokenStream = standardAnalyzer.tokenStream("", new StringReader(text));
                                    CharTermAttribute charTermAttr2 = tokenStream.addAttribute(CharTermAttribute.class);
                                    OffsetAttribute offsetAttribute = tokenStream.addAttribute(OffsetAttribute.class);
                                    PositionIncrementAttribute posincreatt2 = tokenStream.addAttribute(PositionIncrementAttribute.class);
                                    tokenStream.reset();

                                    while (tokenStream.incrementToken()) {
                                        int startOffset = offsetAttribute.startOffset() + lastEndOffset;
//System.out.println("startOffset"+startOffset);
                                        int endOffset = offsetAttribute.endOffset() + lastEndOffset;
//System.out.println("endOffset"+endOffset);
                                        startOffsets.add(startOffset);
                                        endOffsets.add(endOffset);

                                        tmpOffset = endOffset;
                                        int posincr2 = posincreatt2.getPositionIncrement();
                                        posincrs.add(posincr2);

                                        String token = charTermAttr2.toString();
                                        if (currentPath.equals("/root/")) {
                    allTokens.append(token).append(" ");
                } else {
                    //String pathSubstring = currentPath.startsWith("root/") ? currentPath.substring(5) : currentPath;
                    allTokens.append(token).append("#/").append(currentPath.substring(7)).append(" ");
                }
                                    }
                                    lastEndOffset = tmpOffset;
                                    tokenStream.end();
                                    tokenStream.close();
                                } catch (Exception e) {
                                    throw new RuntimeException("Error tokenizing text: " + text, e);
                                }
                            }
                        }
                    });
                } catch (SAXParseException e) {
                    System.out.println("Skipping invalid XML file due to parse error: " + e.getMessage());
                }
catch (SAXException e) {
                    System.out.println("Skipping invalid XML file due to parse error: " + e.getMessage());
                }


            } catch (Exception e) {
System.out.println("Skipping invalid XML file due to parse error: " + e.getMessage());

                //throw new RuntimeException("Error parsing XML", e);
            }
            return allTokens.toString().trim().split("\\s+");
        }
    }

    public static void main(String[] args) throws Exception {
        String xml = """
                <root>
                    <id>123</id>
                    <title>Lucene Example</title>
                    <abstract>Demonstrating SAX Parsing</abstract>
                    <section>
                        <section name="Introduction">
                            <paragraph>This is a paragraph in the introduction.</paragraph>
                        </section>
                        <section name="Details">
                            <paragraph>This is a paragraph in the details section.</paragraph>
                        </section>
                    </section>
                </root>
                """;

        Analyzer analyzer = new XmlPathAnalyzer();
        try (Reader reader = new StringReader(xml); TokenStream tokenStream = analyzer.tokenStream(null, reader)) {
            CharTermAttribute charTermAttr = tokenStream.addAttribute(CharTermAttribute.class);
            tokenStream.reset();
            while (tokenStream.incrementToken()) {
                // Do something with the token
            }
            tokenStream.end();
        }
    }
}
