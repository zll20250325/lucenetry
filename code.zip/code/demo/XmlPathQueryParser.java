package org.apache.lucene.demo;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import java.util.Stack;
import org.apache.lucene.search.FuzzyQuery2;
import org.apache.lucene.search.FuzzyPhraseQuery;
import org.apache.lucene.index.Term;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.*;
import org.xml.sax.InputSource;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.StringReader;
import java.util.*;

public class XmlPathQueryParser extends QueryParser {

    private final Analyzer analyzer;

    public XmlPathQueryParser(String field, Analyzer analyzer) {
        super(field, analyzer);
        this.analyzer = analyzer;
    }
public static String processTags(String input) {
        Stack<String> stack = new Stack<>();
        StringBuilder result = new StringBuilder();
        int i = 0;

        while (i < input.length()) {
            if (input.charAt(i) == '<') {
                int j = input.indexOf('>', i);
                if (j == -1) break; // Invalid input, no closing ">"
                String tag = input.substring(i + 1, j); // Extract tag without <>
                boolean isEndTag = tag.startsWith("/");

                if (isEndTag) {
                    String endTag = tag.substring(1); // Remove the "/" prefix from the end tag
                    if (!stack.isEmpty() && stack.peek().startsWith("addsg")) {
                        // Add "addsg" if top of stack has "addsg" prefix
                        endTag = "addsg" + endTag;
                    } else if (!stack.isEmpty() && stack.peek().startsWith("minussg")) {
                        // Add "minussg" if top of stack has "minussg" prefix
                        endTag = "minussg" + endTag;
                    }

                    // Compare with the top of the stack and pop it
                    if (!stack.isEmpty() && stack.peek().equals(endTag)) {
                        stack.pop();
                        result.append("</").append(endTag).append(">");
                    }
                } else {
                    // Handle start tag
                    if (tag.startsWith("+")) {
                        tag = "addsg" + tag.substring(1); // Replace "+" with "addsg"
                    } else if (tag.startsWith("-")) {
                        tag = "minussg" + tag.substring(1); // Replace "-" with "minussg"
                    }

                    stack.push(tag);
                    result.append("<").append(tag).append(">");
                }
                i = j + 1; // Move past the '>'
            } else {
                result.append(input.charAt(i)); // Non-tag character
                i++;
            }
        }
        return result.toString();
    }

    @Override
    public Query parse(String query) throws ParseException {
        String query2=processTags(query);
        Map<String, List<String>> pathTextMap = new HashMap<>();
        Set<String> pathOnlySet = new HashSet<>();
        parseXmlToPathTextMap(query2, pathTextMap, pathOnlySet);

        // Phase 2: Construct queries based on the map and set
        List<SubqueryWithPath> subqueries = new ArrayList<>();
        List<FuzzyQuery2> pathonlyqueries = new ArrayList<>();

        for (Map.Entry<String, List<String>> entry : pathTextMap.entrySet()) {
            String path = entry.getKey();
            List<String> texts = entry.getValue();

            if (texts.size() == 1) {
                String text = texts.get(0);
                //if (text.equals(" ")) {
                   // Term term = new Term(field, path);
                    //pathonlyqueries.add(new TermQuery(term));
   //             } else {

                    Query subquery = XmlPathQueryParser.super.parse(text);
                //System.out.println("path:"+path);

                    subqueries.add(new SubqueryWithPath(subquery, path,false));
                //}
            } else {
                boolean allContainPlus = texts.stream().allMatch(text -> text.contains("+"));
                if (allContainPlus) {
                    String combinedText = String.join(" OR ", texts).replace("+", "");
                    path = modifyPathForAddsg(path);
                    Query subquery = XmlPathQueryParser.super.parse(combinedText);
                    subqueries.add(new SubqueryWithPath(subquery, path,allContainPlus));
                } else {
                    for (String text : texts) {
                        Query subquery = XmlPathQueryParser.super.parse(text);
                        subqueries.add(new SubqueryWithPath(subquery, path,allContainPlus));
                    }
                }
            }
        }

        for (String path : pathOnlySet) {
            Term term = new Term(field, path);
            pathonlyqueries.add(new FuzzyQuery2(term));
        }
        //System.out.println("2");
        // Step 2: Extend each subquery with its corresponding path
        for (SubqueryWithPath subqueryWithPath : subqueries) {
subqueryWithPath.query = extendQueryWithPath(subqueryWithPath.query, subqueryWithPath.path,subqueryWithPath.allContainPlus);            //extendQueryWithPath(subqueryWithPath.query, subqueryWithPath.path);
//System.out.println("subqueryWithPath.query:"+subqueryWithPath.query);

        }
        //System.out.println("3");
        // Step 3: Combine the subqueries into a top-level query
        return combineSubqueries(subqueries,pathonlyqueries);
    }

    // Data structure to hold a query and its corresponding path
    private static class SubqueryWithPath {
        Query query;
        String path;
        BooleanClause.Occur occur;
        boolean allContainPlus=false;

        SubqueryWithPath(Query query, String path,boolean allContainPlus) {
            this.query = query;
            this.path = path;
            this.occur = getBooleanClauseOccur(path);
            this.allContainPlus=allContainPlus;
        }
    }

    // Parse the XML input to create queries for each text node and record their paths
    private void parseXmlToPathTextMap(String xml, Map<String, List<String>> pathTextMap, Set<String> pathOnlySet) throws ParseException {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();

            saxParser.parse(new InputSource(new StringReader("<root>" + xml + "</root>")), new DefaultHandler() {
                private final Stack<String> pathStack = new Stack<>();

                @Override
                public void startElement(String uri, String localName, String qName, Attributes attributes) {
                    pathStack.push(qName);
                }

                @Override
                public void endElement(String uri, String localName, String qName) {
                    pathStack.pop();
                }

                @Override
                public void characters(char[] ch, int start, int length) {
                    String text = new String(ch, start, length).trim();
 String path ="/"+ String.join("//", pathStack)+"/";
                    //String path = String.join("/", pathStack);

                    if (!text.isEmpty()) {
        pathTextMap.computeIfAbsent(path, k -> new ArrayList<>()).add(text);
                    } else {
                //System.out.println("path:"+path);
                        pathOnlySet.add(path);
                    }
                }
            });

        } 
catch (ParserConfigurationException |SAXException|IOException e) {
            throw new RuntimeException("Error parsing XML input", e);
        }

    }

private String modifyPathForAddsg(String path) {
        int lastSlashIndex = path.lastIndexOf("//");
        if (lastSlashIndex == -1) {
            return "/addsg" + path.substring(1);
        } else {
            return path.substring(0, lastSlashIndex + 2) + "addsg" + path.substring(lastSlashIndex + 2);
        }
    }

    // Extend the query with its corresponding path
    private Query extendQueryWithPath(Query query, String path,boolean allContainPlus) {
    /* 
    if ("/root/".equals(path)) {
        return query;  // Don't modify the query if the path is "root"
    }
    */
    String modifiedPath = path.replace("addsg", "").replace("minussg", "").replace("/root/", "");
    if (query instanceof TermQuery) {
        TermQuery termQuery = (TermQuery) query;
        Term term = termQuery.getTerm();
        String extendedTermText = term.text() + "#" + modifiedPath;
        Query query2 = new FuzzyQuery2(new Term(term.field(), extendedTermText));
        if ("/root/".equals(path)) {
        BooleanQuery.Builder builder = new BooleanQuery.Builder();
        builder.add(query2, BooleanClause.Occur.SHOULD);  // query2
        builder.add(query, BooleanClause.Occur.SHOULD);   // original query
        query = builder.build();
    } else {
        query = query2;
    }
    } else if (query instanceof BooleanQuery) {
        if(!allContainPlus&&path.contains("addsg")){
        System.out.println("xiangpaojunjun");
List<Term> termList = new ArrayList<>();
    List<Integer> groupList = new ArrayList<>();
    int groupCounter = 0;

    Queue<Query> queue = new LinkedList<>();
    queue.add(query);

    while (!queue.isEmpty()) {
        Query currentQuery = queue.poll();

        if (currentQuery instanceof BooleanQuery) {
            for (BooleanClause clause : ((BooleanQuery) currentQuery).clauses()) {
                queue.add(clause.query()); // Add child queries to the queue
            }
        } else if (currentQuery instanceof TermQuery) {
            TermQuery termQuery = (TermQuery) currentQuery;
            String extendedTermText = termQuery.getTerm().text() + "#" + modifiedPath;
termList.add(new Term(termQuery.getTerm().field(),extendedTermText));
            groupList.add(groupCounter);
            groupCounter++; // Move to the next group
        } else if (currentQuery instanceof PhraseQuery) {
            PhraseQuery phraseQuery = (PhraseQuery) currentQuery;
            for (Term term : phraseQuery.getTerms()) {
                String extendedTermText = term.text() + "#" + modifiedPath;

                termList.add(new Term(term.field(),extendedTermText));
                groupList.add(groupCounter);
            }
            groupCounter++; // Move to the next group after processing a phrase
        }
    }

    // Convert lists to arrays
    Term[] terms = termList.toArray(new Term[0]);
    int[] groupIndices = groupList.stream().mapToInt(i -> i).toArray();

    // Call buildBooleanQuery
    return new FuzzyPhraseQuery(terms, groupIndices);}


else{
BooleanQuery booleanQuery = (BooleanQuery) query;
        BooleanQuery.Builder builder = new BooleanQuery.Builder();
        for (BooleanClause clause : booleanQuery.clauses()) {
            Query extendedSubquery = extendQueryWithPath(clause.query(), modifiedPath,allContainPlus);
            //builder.add(extendedSubquery, clause.getOccur());
builder.add(extendedSubquery, clause.occur());

        }
        query = builder.build();
    } 
}else if (query instanceof PhraseQuery) {
        PhraseQuery phraseQuery = (PhraseQuery) query;
        //PhraseQuery.Builder builder = new PhraseQuery.Builder();
        Term[] terms = phraseQuery.getTerms();
        //int[] positions = phraseQuery.getPositions();
        for (int i = 0; i < terms.length; i++) {
            Term term = terms[i];
            
            String extendedTermText = term.text() + "#" + modifiedPath;
            terms[i]=new Term(term.field(), extendedTermText);
System.out.println(term);
            //builder.add(new Term(term.field(), extendedTermText), positions[i]);
        }
        Query query2 =new FuzzyPhraseQuery(terms,new int[terms.length]);
if ("/root/".equals(path)) {
        BooleanQuery.Builder builder = new BooleanQuery.Builder();
        builder.add(query2, BooleanClause.Occur.SHOULD);  // query2
        builder.add(query, BooleanClause.Occur.SHOULD);   // original query
        query = builder.build();
    } else {
        query = query2;
    }
    }
    // Add more cases for other query types if necessary
    return query;
}


    // Combine subqueries into a top-level query (disjunction by default)
    private Query combineSubqueries(List<SubqueryWithPath> subqueries, List<FuzzyQuery2> pathonlyqueries) {
    BooleanQuery.Builder builder = new BooleanQuery.Builder();

    for (SubqueryWithPath subqueryWithPath : subqueries) {
        BooleanClause.Occur occur = getBooleanClauseOccur(subqueryWithPath.path);
        builder.add(subqueryWithPath.query, subqueryWithPath.occur);
    }

    for (FuzzyQuery2 pathonlyquery : pathonlyqueries) {
        BooleanClause.Occur occur = getBooleanClauseOccur(pathonlyquery.getTerm().text());
String path = pathonlyquery.getTerm().text();

        // First condition: If the path is "root", skip this query
        if ("/root/".equals(path)) {
            continue;  // Skip this path-only query
        }
String modifiedTermText = pathonlyquery.getTerm().text()
            .replace("addsg", "") // Remove "addsg"
            .replace("minussg", "").replace("/root/", ""); // Remove "minussg"
    
    Term modifiedTerm = new Term(pathonlyquery.getTerm().field(), modifiedTermText);
    FuzzyQuery2 modifiedTermQuery = new FuzzyQuery2(modifiedTerm);
        builder.add(modifiedTermQuery, occur);
    }

    return builder.build();
}

private static BooleanClause.Occur getBooleanClauseOccur(String path) {
    if (path.contains("minussg")) {
        return BooleanClause.Occur.MUST_NOT; // "-"
    } else if (path.contains("addsg")) {
        return BooleanClause.Occur.MUST; // "+"
    } else {
        return BooleanClause.Occur.SHOULD; // Default
    }
}


    public static void main(String[] args) throws ParseException {
        // Example usage
        String xmlInput ="""
<article>
<bdy> <sec>+"nonmonotonic reasoning"</sec> </bdy>
<hdr>
<yr>+1999</yr>
<yr>+2000</yr>
</hdr>
<tig> <atl>-calendar</atl> </tig>
</article>
""";
        Analyzer analyzer = new StandardAnalyzer();
        XmlPathQueryParser parser = new XmlPathQueryParser("contents", analyzer);
        Query query = parser.parse(xmlInput);
        System.out.println("xiangpaojunjun");

        System.out.println(query);
    }
}
