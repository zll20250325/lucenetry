/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.demo;

import java.io.Reader;
import java.io.StringReader;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;
import java.util.Stack;
import java.util.*;
import java.util.AbstractMap.SimpleEntry;

import org.apache.lucene.analysis.XmlPathAnalyzer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Date;
import java.util.Objects;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.demo.knn.DemoEmbeddings;
import org.apache.lucene.demo.knn.KnnVectorDict;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.KeywordField;
import org.apache.lucene.document.KnnFloatVectorField;
import org.apache.lucene.document.LongField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.VectorSimilarityFunction;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.IOUtils;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.ParserConfigurationException;
/**
 * Index all text files under a directory.
 *
 * <p>This is a command-line application demonstrating simple Lucene indexing. Run it with no
 * command-line arguments for usage information.
 */
public class IndexFiles3_1 implements AutoCloseable {
  static final String KNN_DICT = "knn-dict";

  // Calculates embedding vectors for KnnVector search
  private final DemoEmbeddings demoEmbeddings;
  private final KnnVectorDict vectorDict;

  private IndexFiles3_1(KnnVectorDict vectorDict) throws IOException {
    if (vectorDict != null) {
      this.vectorDict = vectorDict;
      demoEmbeddings = new DemoEmbeddings(vectorDict);
    } else {
      this.vectorDict = null;
      demoEmbeddings = null;
    }
  }

  /** Index all text files under a directory. */
  public static void main(String[] args) throws Exception {
    String usage =
        "java org.apache.lucene.demo.IndexFiles3_1"
            + " [-index INDEX_PATH] [-docs DOCS_PATH] [-update] [-knn_dict DICT_PATH]\n\n"
            + "This indexes the documents in DOCS_PATH, creating a Lucene index "
            + "in INDEX_PATH that can be searched with SearchFiles\n"
            + "IF DICT_PATH contains a KnnVector dictionary, the index will also support KnnVector search";
    String indexPath = "index";
    String docsPath = null;
    String vectorDictSource = null;
    boolean create = true;
    for (int i = 0; i < args.length; i++) {
      switch (args[i]) {
        case "-index":
          indexPath = args[++i];
          break;
        case "-docs":
          docsPath = args[++i];
          break;
        case "-knn_dict":
          vectorDictSource = args[++i];
          break;
        case "-update":
          create = false;
          break;
        case "-create":
          create = true;
          break;
        default:
          throw new IllegalArgumentException("unknown parameter " + args[i]);
      }
    }

    if (docsPath == null) {
      System.err.println("Usage: " + usage);
      System.exit(1);
    }

    final Path docDir = Paths.get(docsPath);
    if (!Files.isReadable(docDir)) {
      System.out.println(
          "Document directory '"
              + docDir.toAbsolutePath()
              + "' does not exist or is not readable, please check the path");
      System.exit(1);
    }

    Date start = new Date();
    try {
      System.out.println("Indexing to directory '" + indexPath + "'...");

      Directory dir = FSDirectory.open(Paths.get(indexPath));
      Analyzer analyzer = new StandardAnalyzer();
      IndexWriterConfig iwc = new IndexWriterConfig(analyzer);

      if (create) {
        // Create a new index in the directory, removing any
        // previously indexed documents:
        iwc.setOpenMode(OpenMode.CREATE);
      } else {
        // Add new documents to an existing index:
        iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);
      }

      // Optional: for better indexing performance, if you
      // are indexing many documents, increase the RAM
      // buffer.  But if you do this, increase the max heap
      // size to the JVM (e.g. add -Xmx512m or -Xmx1g):
      //
      // iwc.setRAMBufferSizeMB(256.0);

      KnnVectorDict vectorDictInstance = null;
      long vectorDictSize = 0;
      if (vectorDictSource != null) {
        KnnVectorDict.build(Paths.get(vectorDictSource), dir, KNN_DICT);
        vectorDictInstance = new KnnVectorDict(dir, KNN_DICT);
        vectorDictSize = vectorDictInstance.ramBytesUsed();
      }

      try (IndexWriter writer = new IndexWriter(dir, iwc);
          IndexFiles3_1 IndexFiles3_1 = new IndexFiles3_1(vectorDictInstance)) {
        IndexFiles3_1.indexDocs(writer, docDir);

        // NOTE: if you want to maximize search performance,
        // you can optionally call forceMerge here.  This can be
        // a terribly costly operation, so generally it's only
        // worth it when your index is relatively static (ie
        // you're done adding documents to it):
        //
        // writer.forceMerge(1);
      } finally {
        IOUtils.close(vectorDictInstance);
      }

      Date end = new Date();
      try (IndexReader reader = DirectoryReader.open(dir)) {
        System.out.println(
            "Indexed "
                + reader.numDocs()
                + " documents in "
                + (end.getTime() - start.getTime())
                + " ms");
        if (Objects.isNull(vectorDictSource) == false
            && reader.numDocs() > 100
            && vectorDictSize < 1_000_000
            && System.getProperty("smoketester") == null) {
          throw new RuntimeException(
              "Are you (ab)using the toy vector dictionary? See the package javadocs to understand why you got this exception.");
        }
      }
    } catch (IOException e) {
      System.out.println(" caught a " + e.getClass() + "\n with message: " + e.getMessage());
    }
  }

  /**
   * Indexes the given file using the given writer, or if a directory is given, recurses over files
   * and directories found under the given directory.
   *
   * <p>NOTE: This method indexes one document per input file. This is slow. For good throughput,
   * put multiple documents into your input file(s). An example of this is in the benchmark module,
   * which can create "line doc" files, one document per line, using the <a
   * href="../../../../../contrib-benchmark/org/apache/lucene/benchmark/byTask/tasks/WriteLineDocTask.html"
   * >WriteLineDocTask</a>.
   *
   * @param writer Writer to the index where the given file/dir info will be stored
   * @param path The file to index, or the directory to recurse into to find files to index
   * @throws IOException If there is a low-level I/O error
   */
  void indexDocs(final IndexWriter writer, Path path) throws IOException {
    if (Files.isDirectory(path)) {
      Files.walkFileTree(
          path,
          new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
              try {
                indexDoc(writer, file, attrs.lastModifiedTime().toMillis());
              } 
              catch (Exception ignore) 
                  // catch (
                  //   @SuppressWarnings("unused")
                  //   IOException ignore) 
                  {
                ignore.printStackTrace(System.err);
                // don't index files that can't be read.
              }
              return FileVisitResult.CONTINUE;
            }
          });
    } else {
      indexDoc(writer, path, Files.getLastModifiedTime(path).toMillis());
    }
  }
private String wrapXml(Reader inputReader) throws IOException {
            StringBuilder sb = new StringBuilder();
            int character;
            while ((character = inputReader.read()) != -1) {
                sb.append((char) character);
            }
            return "<root>" + sb.toString() + "</root>";
        }
 void indexDoc(IndexWriter writer, Path file, long lastModified) throws IOException {
    try (BufferedReader reader = Files.newBufferedReader(file)) {
        // Create a SAXParserFactory and set it up
        SAXParserFactory factory = SAXParserFactory.newInstance();
factory.setFeature("http://apache.org/xml/features/nonvalidating/load-dtd-grammar", false);
                factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

        SAXParser parser = factory.newSAXParser();

        // Parse the XML file with the SAXParser, directly using the new handler
String wrappedXml = wrapXml(reader);

                Reader wrappedReader = new StringReader(wrappedXml);

        parser.parse(new InputSource(wrappedReader), new DefaultHandler() {
            private Stack<String> pathStack = new Stack<>();
            private String lastPoppedPath = ""; 
//private StringBuilder secText = null;
            //private StringBuilder pText = null;
private StringBuilder pText =new StringBuilder();

private StringBuilder otherText = new StringBuilder(); 

private List<String[]> dataToIndex = new ArrayList<>();

private boolean is_id_now=false;
private String id;

void indexDocument(IndexWriter writer, String fullXML, String fullDocumentPath, long lastModified) throws IOException {
    Document doc = new Document();

    // Add the full document path as a field named "path".
    // Use a field that is indexed but don't tokenize it or store term frequency info.
    doc.add(new KeywordField("path", fullDocumentPath, Field.Store.YES));

    // Add the last modified date of the file as a field named "modified".
    // This is indexed with points and doc values for efficient filtering and sorting.
    doc.add(new LongField("modified", lastModified, Field.Store.NO));

    // Add the contents of the document (XML) to a field named "contents".
    // Specify a Reader to tokenize and index the text.
    doc.add(new TextField("contents", fullXML, Field.Store.NO));
//System.out.println("fullXML:"+fullXML);
    // Commenting out the demo embeddings part as per your instruction.
    // if (demoEmbeddings != null) {
    //     try (InputStream in = Files.newInputStream(file)) {
    //         float[] vector =
    //             demoEmbeddings.computeEmbedding(
    //                 new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)));
    //         doc.add(
    //             new KnnFloatVectorField(
    //                 "contents-vector", vector, VectorSimilarityFunction.DOT_PRODUCT));
    //     }
    // }

    if (writer.getConfig().getOpenMode() == OpenMode.CREATE) {
        // New index, so we just add the document (no old document can be there):
        System.out.println("adding " + fullDocumentPath);
        writer.addDocument(doc);
    } else {
        // Existing index (an old copy of this document may have been indexed) so
        // we use updateDocument instead to replace the old one matching the exact
        // path, if present:
        System.out.println("updating " + fullDocumentPath);
        writer.updateDocument(new Term("path", fullDocumentPath), doc);
    }
}

            @Override
            public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
if (qName.equals("id")) {
                    is_id_now =true;
                    
                }

                String currentPath = String.join("/", pathStack) + "/" + qName;
if (lastPoppedPath == null || lastPoppedPath.isEmpty()) {
        pathStack.push(qName + "[1]");
return;}
                String lastPoppedPathStructure = lastPoppedPath.substring(0, lastPoppedPath.lastIndexOf('[')); 

                if (currentPath.equals(lastPoppedPathStructure)) {
                    String countStr = lastPoppedPath.substring(lastPoppedPath.lastIndexOf('[') + 1, lastPoppedPath.length() - 1);
                    int lastTagCount = Integer.parseInt(countStr) + 1; 
                    pathStack.push(qName + "[" + lastTagCount + "]");
                } else {
                    pathStack.push(qName + "[1]");
                }

/*
if (qName.equals("p")) {
                    pText = new StringBuilder();
                }
*/
/*
if (qName.equals("id")) {
                    is_id_now =true;
                    
                }
*/
            }

            @Override
            public void endElement(String uri, String localName, String qName) throws SAXException {

                lastPoppedPath = String.join("/", pathStack);
                pathStack.pop();
if (qName.equals("id")) {
                    is_id_now =false;
                }

                if (qName.equals("p") && pText != null) {
                    // Store the paragraph text and its file path
                    dataToIndex.add(new String[] {file.toString()+"#" + lastPoppedPath.substring(7), pText.toString()});
                    pText.setLength(0); // Clear the data structure after storing
                }

                // When "article" is encountered, index all stored data
                if (qName.equals("article")) {
String originalDir = writer.getDirectory().toString();
originalDir=originalDir.substring(originalDir.indexOf("@")+1,originalDir.indexOf(" "));
String newDir=originalDir+"\\"+id;
try{
Directory dir2 = FSDirectory.open(Paths.get(newDir));
Analyzer analyzer2 = new StandardAnalyzer();
      IndexWriterConfig iwc2 = new IndexWriterConfig(analyzer2);
iwc2.setOpenMode(writer.getConfig().getOpenMode());
 //iwc2.setRAMBufferSizeMB(256.0);

IndexWriter writer2 = new IndexWriter(dir2, iwc2);

System.out.println("newDir:"+newDir);
                    for (String[] entry : dataToIndex) {
                        try {
                            // Index the section/paragraph content
                            //String combinedText = entry[1] + otherText.toString();
                indexDocument(writer, entry[1], entry[0], lastModified);
                        } catch (IOException e) {
                            // Handle the IOException here (log it, handle it, or rethrow as a runtime exception)
                            System.err.println("Error indexing document: " + entry[0]+entry[1]);
                            e.printStackTrace();
                        }
                    }
writer2.close();
dir2.close();

}catch(IOException e) {System.err.println("Error indexing document: " );
                            e.printStackTrace();
}

                    // Clear the list  after indexing
                    dataToIndex.clear();
                    otherText.setLength(0);
                }
            }


            @Override
            public void characters(char[] ch, int start, int length) throws SAXException {
                String currentText = new String(ch, start, length).trim();
            /*
                if (currentText.isEmpty()) {
                    return; 
                }
            */
if(is_id_now){
                    id=currentText;
                    System.out.println("id"+id);

                }

                boolean isTargetTagFound1 = false;

                StringBuilder fullXML = new StringBuilder();
                //StringBuilder currentPath = new StringBuilder();
            
                for (String tag : pathStack) {
                    String baseTag = tag.replaceAll("\\[\\d+\\]", "");
            
                    if (tag.matches("p\\[\\d+\\]")) {
                        isTargetTagFound1 = true;
                    }

            
                    fullXML.append("<").append(baseTag).append(">");
                    //currentPath.append(tag).append("/");
                }
            
                //if (isTargetTagFound1||isTargetTagFound2) {
                    fullXML.append(currentText);
            
                    for (int i = pathStack.size() - 1; i >= 0; i--) {
                        String baseTag = pathStack.get(i).replaceAll("\\[\\d+\\]", "");
                        fullXML.append("</").append(baseTag).append(">");
                    }
String fullXMLStr = fullXML.toString();
fullXMLStr = fullXMLStr.substring(6, fullXMLStr.length() - 7);
if (isTargetTagFound1 && pText != null) {
                    pText.append(currentText);
/*
System.out.println(
"currentText"+currentText);
*/
                }  

                    otherText.append(fullXMLStr);  // For other parts of the text
                
          
//String fullDocumentPath = file.toString() + currentPath.toString(); 

                    // Call indexDocument with 4 parameters
                    
                //}
            }
        });
    }catch (ParserConfigurationException | SAXException | IOException e) {
        // Handle SAX parsing and IOExceptions here
        System.err.println("Error processing the file: " + file);
        e.printStackTrace();
    }
}

  @Override
  public void close() throws IOException {
    IOUtils.close(vectorDict);
  }
}
