package org.apache.lucene.util;
import org.apache.lucene.util.BytesRef;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.apache.lucene.util.BytesRefBuilder;

public class BytesRefArray2 {
    private BytesRef[] bytesRefs;

    public BytesRefArray2(BytesRef[] bytesRefs) {
        this.bytesRefs = bytesRefs;
    }
    
public int compareTo(BytesRefBuilder[] other) {
        int minLength = Math.min(this.bytesRefs.length, other.length);
        
        // Compare each element until a difference is found
        for (int i = 0; i < minLength; i++) {
            int result = this.bytesRefs[i].compareTo(other[i].get());
            if (result != 0) {
                return result;
            }
        }
        
        // If all compared elements are equal, compare based on the lengths of the arrays
        return Integer.compare(this.bytesRefs.length, other.length);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        BytesRefArray2 that = (BytesRefArray2) obj;
        return Arrays.equals(this.bytesRefs, that.bytesRefs);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(this.bytesRefs);
    }

    public static void main(String[] args) {
        BytesRef[] array1 = new BytesRef[] { new BytesRef("key1"), new BytesRef("key2") };
        BytesRef[] array2 = new BytesRef[] { new BytesRef("key1"), new BytesRef("key2") };
        
        Map<BytesRefArray2, String> map = new HashMap<>();
        map.put(new BytesRefArray2(array1), "value1");

        System.out.println(map.get(new BytesRefArray2(array2))); // Output: value1
    }
}
